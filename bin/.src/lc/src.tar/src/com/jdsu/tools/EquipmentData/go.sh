#!/bin/sh
j -c /u01/app/oracle/product/9.2.0/jdbc/lib/classes12.jar Equipment.java $1
