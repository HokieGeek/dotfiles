CLASSPATH=/u01/app/oracle/product/9.2.0/jdbc/lib/classes12.jar:/ada/tdce/java:.:~/cbt_ops/src
javac PMDHCleaner.java
javac PassiveDataParser.java
javac CSVGenerator.java
javac PMDataHandler.java
